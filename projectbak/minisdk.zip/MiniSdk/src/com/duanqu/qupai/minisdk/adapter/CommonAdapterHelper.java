package com.duanqu.qupai.minisdk.adapter;

public interface CommonAdapterHelper {

    public abstract Object getItemList();

    public abstract void notifyChange();

}
